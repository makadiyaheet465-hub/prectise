package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practical16Application {

	public static void main(String[] args) {
		SpringApplication.run(Practical16Application.class, args);
	}

}

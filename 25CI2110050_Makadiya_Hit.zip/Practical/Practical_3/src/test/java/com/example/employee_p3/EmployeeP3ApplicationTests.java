package com.example.employee_p3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeP3ApplicationTests {

    @Test
    void contextLoads() {
    }

}

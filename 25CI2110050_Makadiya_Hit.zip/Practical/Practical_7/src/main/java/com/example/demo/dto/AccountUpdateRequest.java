package com.example.demo.dto;

public class AccountUpdateRequest {
	
	private String accountHolder;

	public AccountUpdateRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

}

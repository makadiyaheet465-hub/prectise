package com.example.employee_p5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeP5Application {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeP5Application.class, args);
    }

}

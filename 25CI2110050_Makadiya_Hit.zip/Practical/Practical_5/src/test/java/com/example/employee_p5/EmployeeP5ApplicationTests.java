package com.example.employee_p5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeP5ApplicationTests {

    @Test
    void contextLoads() {
    }

}

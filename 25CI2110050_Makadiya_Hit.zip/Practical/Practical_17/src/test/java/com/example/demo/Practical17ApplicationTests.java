package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practical17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
